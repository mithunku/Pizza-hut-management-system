from tkinter import *
import time
from sqlite3 import *
import random
from tkinter import messagebox
from tkinter import ttk
from orderdetails import *
from admin import *
from werkzeug.security import generate_password_hash , check_password_hash

global index

class Pizza:

    cartlist=[]
    amount=0
#--  page 1------
    def main(sf):
        try:
            sf.scr.destroy()
            sf.scr=Tk()
        except:
            try:
                sf.scr=Tk()
            except:
                pass

        sf.scr.geometry("1366x768")
        sf.scr.title("PIZZA SAFARI")
        #sf.scr.resizable(False, False)
        sf.scr.iconbitmap('p.ico')
        sf.mainf1=Frame(sf.scr,height=150,width=1366)
        sf.logo=PhotoImage(file="pzzahut.png")
        sf.l=Label(sf.mainf1,image=sf.logo)
        sf.l.place(x=0,y=0)
        sf.mainf1.pack(fill=BOTH,expand=1)
        sf.mainf2=Frame(sf.scr,height=618,width=1366)
        sf.c=Canvas(sf.mainf2,height=618,width=1366)
        sf.c.pack()
        sf.back=PhotoImage(file="pizzamain.png")
        sf.c.create_image(683,284,image=sf.back)
        sf.lab=Button(sf.mainf2,text= "Click Here to enter the World of Pizzas",command=lambda:sf.Login(),cursor="hand2", bd=10 ,font=("cooper black",30, 'bold'),fg="white",bg="#0b1335")
        sf.lab.place(x=250,y=250)
        sf.mainf2.pack(fill=BOTH,expand=1)
        sf.scr.mainloop()
    #----2nd page--------------

    def Login(sf):

        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.loginf1 = Frame(sf.scr, height=150, width=1366)
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.ba = Label(sf.loginf1, image=sf.logo, height=150).place(x=0, y=0)
        sf.home = Button(sf.loginf1, text="Home", command=lambda: sf.main(), bg="#0b1335", cursor="hand2", bd=4,
                         fg="white", font=("cooper black", 16))
        sf.home.place(x=800, y=100)
        sf.adlog = Button(sf.loginf1, text="Administrator Login", command=lambda: sf.Adminlogin(), cursor="hand2", bd=4,
                          bg="#0b1335", fg="white", font=("cooper black", 16))
        sf.adlog.place(x=925, y=100)
        sf.abt = Button(sf.loginf1, text="About Us", bg="#0b1335", cursor="hand2", bd=4, fg="white",
                        font=("cooper black", 16))
        sf.abt.config(command=lambda: sf.about())
        sf.abt.place(x=1210, y=100)

        sf.loginf1.pack(fill=BOTH, expand=1)
        sf.loginf2 = Frame(sf.scr, height=618, width=1366)
        sf.c = Canvas(sf.loginf2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.c.create_rectangle(50, 100, 700, 450, fill="#d3ede6", outline="white", width=6)
        sf.log = Label(sf.loginf2, text="LOGIN", fg="white", bg="#0b1335", width=26, font=("cooper black", 27))
        sf.log.place(x=59, y=105)
        sf.lab1 = Label(sf.loginf2, text="UserName", bg="#d3ede6", font=("cooper black", 22))
        sf.lab1.place(x=100, y=180)
        sf.user = Entry(sf.loginf2, bg="white", font=("cooper black", 22), bd=6, justify='left')
        sf.user.place(x=320, y=180)
        sf.lab2 = Label(sf.loginf2, text="Password", bg="#d3ede6", font=("cooper black", 22))
        sf.lab2.place(x=105, y=250)
        sf.pasd = Entry(sf.loginf2, bg="white", font=("cooper black", 22), bd=6, justify='left')
        sf.pasd.place(x=320, y=250)
        sf.lg = Button(sf.loginf2, text="Login", cursor="hand2", command=lambda: sf.logindata(), fg="white",  bg="#0b1335", font=("cooper black", 20), bd=4)

        sf.lg.place(x=180, y=320)

        def clear(sf):
            sf.user.delete(0, END)
            sf.pasd.delete(0, END)

        sf.cl = Button(sf.loginf2, text="Clear", cursor="hand2", command=lambda: clear(sf), fg="white", bg="#0b1335",
                       font=("cooper black", 20), bd=4)
        sf.cl.place(x=450, y=320)
        sf.rg = Button(sf.loginf2, text="New to Pizza Hut", command=lambda: sf.Register(), fg="white",
                       cursor="hand2", bg="#8c68c1", font=("cooper black", 20), bd=6)
        sf.rg.place(x=200, y=390)
        sf.c.create_rectangle(850, 120, 1310, 480, fill="#d3ede6", outline="white", width=4)
        sf.ext = PhotoImage(file="p4.png")
        sf.url = Label(sf.loginf2, image=sf.ext, cursor="hand2").place(x=855, y=125)
        sf.loginf2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()

    def Adminlogin(sf):
        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.adminf1 = Frame(sf.scr, height=150, width=1366)
        sf.c = Canvas(sf.adminf1, height=150, width=1366)
        sf.c.pack()
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.c.create_image(683, 75, image=sf.logo)
        sf.home = Button(sf.adminf1, text="Home", command=lambda: sf.main(), bg="#0b1335", cursor="hand2", fg="white",
                         bd=5, font=("default", 16, 'bold'))
        sf.home.place(x=1000, y=90)

        sf.adminf1.pack(fill=BOTH, expand=1)
        sf.adminf2 = Frame(sf.scr, height=618, width=1366)

        sf.c = Canvas(sf.adminf2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.c.create_rectangle(350, 100, 1016, 450, fill="#d3ede6", outline="white", width=6)
        sf.log = Label(sf.adminf2, text="ADMIN LOGIN", fg="white", bg="#0b1335", width=27, font=("cooper black", 27))
        sf.log.place(x=357, y=110)
        sf.lab1 = Label(sf.adminf2, text="UserName", bg="#d3ede6", font=("cooper black", 22))
        sf.lab1.place(x=400, y=200)
        sf.usera = Entry(sf.adminf2, bg="white", font=("cooper black", 22), bd=5)
        sf.usera.place(x=650, y=200)
        sf.lab2 = Label(sf.adminf2, text="Password", bg="#d3ede6", font=("cooper black", 22))
        sf.lab2.place(x=405, y=270)
        sf.pasda = Entry(sf.adminf2, bg="white", font=("cooper black", 22), bd=5)
        sf.pasda.place(x=650, y=270)
        sf.lg = Button(sf.adminf2, text="Login", cursor="hand2", fg="white", bg="#0b1335", command=lambda: sf.admindatabase(), font=("copper black", 20, 'bold'), bd=5)

        sf.lg.place(x=650, y=350)
        sf.cl = Button(sf.adminf2, text="Back", cursor="hand2", fg="white", bg="#0b1335", command=lambda: sf.Login(),
                       font=("copper black", 20, 'bold'), bd=5)
        sf.cl.place(x=400, y=350)

        def clear(sf):
            sf.usera.delete(0, END)
            sf.pasda.delete(0, END)

        sf.rg = Button(sf.adminf2, text="Clear", fg="white", cursor="hand2", bg="#0b1335", command=lambda: clear(sf),
                       bd=5, font=("copper black", 20, 'bold'))
        sf.rg.place(x=900, y=350)

        sf.adminf2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()


#----------admin data check-------------
    def admindatabase(sf):
        username='nithin'
        passd='1234'

        if username==sf.usera.get() and passd==sf.pasda.get():
            messagebox.showinfo("Admin", "You have Successfully Log In")
            sf.adminmain()

        else:
            messagebox.showinfo("log in failed")

    def adminmain(sf):
        orderd2()
#----------register page---------------
    def Register(sf):
        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.regf1 = Frame(sf.scr, height=150, width=1366)
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.ba = Label(sf.regf1, image=sf.logo, height=150).place(x=0, y=0)
        sf.home = Button(sf.regf1, text="Home", command=lambda: sf.main(), bg="#0b1335", cursor="hand2", fg="white",
                         font=("default", 16))
        sf.home.place(x=800, y=100)
        sf.adlog = Button(sf.regf1, text="Administrator Login", command=lambda: sf.Adminlogin(), cursor="hand2",
                          bg="#0b1335", fg="white", font=("default", 16))
        sf.adlog.place(x=950, y=100)
        sf.abt = Button(sf.regf1, text="About Us", command=lambda: sf.about(), bg="#0b1335", cursor="hand2", fg="white",
                        font=("default", 16))
        sf.abt.place(x=1210, y=100)

        sf.regf1.pack(fill=BOTH, expand=1)

        sf.regf2 = Frame(sf.scr, height=618, width=1366)
        sf.c = Canvas(sf.regf2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.c.create_rectangle(150, 100, 1216, 450, fill="#d3ede6", outline="white", width=6)
        sf.log = Label(sf.regf2, text="REGISTRATION", fg="white", bg="#0b1335", width=20, font=("cooper black", 27))
        sf.log.place(x=480, y=120)
        sf.lab1 = Label(sf.regf2, text="FirstName", bg="#d3ede6", font=("cooper black", 18))
        sf.lab1.place(x=190, y=200)
        sf.first = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.first.place(x=430, y=200)
        sf.lab2 = Label(sf.regf2, text="LastName", bg="#d3ede6", font=("cooper black", 18))
        sf.lab2.place(x=730, y=200)
        sf.last = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.last.place(x=920, y=200)
        sf.lab3 = Label(sf.regf2, text="Username", bg="#d3ede6", font=("cooper black", 18))
        sf.lab3.place(x=190, y=250)
        sf.usern = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.usern.place(x=430, y=250)
        sf.lab4 = Label(sf.regf2, text="Password", bg="#d3ede6", font=("cooper black", 18))
        sf.lab4.place(x=730, y=250)
        sf.passd = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.passd.place(x=920, y=250)
        sf.lab5 = Label(sf.regf2, text="Email", bg="#d3ede6", font=("cooper black", 18))
        sf.lab5.place(x=190, y=300)
        sf.email = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.email.place(x=430, y=300)
        sf.lab6 = Label(sf.regf2, text="Mobile No.", bg="#d3ede6", font=("cooper black", 18))
        sf.lab6.place(x=730, y=300)
        sf.mob = Entry(sf.regf2, bg="white", width=15, font=("cooper black", 18), bd=5)
        sf.mob.place(x=920, y=300)
        sf.bc = Button(sf.regf2, text="Back", cursor="hand2", command=lambda: sf.Login(), fg="white", bg="#0b1335",font=("cooper black", 18), bd=5)

        sf.bc.place(x=370, y=370)
        sf.rg = Button(sf.regf2, text="Register", cursor="hand2", fg="white", bg="#0b1335",   command=lambda: sf.Regdatabase(), font=("cooper black", 18), bd=5)


        sf.rg.place(x=610, y=370)

        def clear(sf):
            sf.usern.delete(0, END)
            sf.passd.delete(0, END)
            sf.first.delete(0, END)
            sf.last.delete(0, END)
            sf.email.delete(0, END)
            sf.mob.delete(0, END)

        sf.cl = Button(sf.regf2, text="Clear", cursor="hand2", fg="white", bg="#0b1335", command=lambda: clear(sf),
                       font=("cooper black", 18), bd=5)
        sf.cl.place(x=910, y=370)
        sf.regf2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()



#-------register database----------------

    def Regdatabase(sf):
        outfile = open('data.txt', 'a+')
        ifile=open('data3.txt','a+')
        sf.reguser = sf.usern.get()
        #sf.regpasd = hashlib.sha256(str.encode(sf.passd.get())).hexdigest()
        sf.regpasd=sf.passd.get()
        sf.firstname = sf.first.get()
        sf.lastname = sf.last.get()
        sf.Email = sf.email.get()
        sf.Mob = sf.mob.get()
        encpasswd=generate_password_hash(sf.regpasd)
        if sf.reguser == "" or sf.regpasd == "" or sf.firstname == "" or sf.lastname == "" or sf.email=="" or sf.mob=="":

            messagebox.showinfo("Register", "Empty Entry is not Allowed(except Email)")
        else:

            messagebox.showinfo("Register", "You are Successfully Registered")
            c=sf.calindex()
            if sf.calindex()==0:
                c=0
            else:
                file=open('data.txt','r')
                for i in file:
                    fields=i.split('|')
                c=int(fields[0])+1


            outfile.write(str(c)+'|'+sf.reguser + '|' + encpasswd + '|' + sf.firstname+'|'+sf.lastname + '|' + sf.Email+'|'+'$')
            outfile.write('\n')
            ifile.write(sf.reguser +  '|' + sf.firstname + '|' + sf.lastname + '|' + sf.Email + '|' +'$')
            ifile.write('\n')
            outfile.close()
            ifile.close()

            sf.Login()

    def calindex(sf):
        file=open('data.txt','r')
        count=0


        for i in file:

            count=count+1

        index=count

        return index


    def pizmain(sf):
        sf.scr.destroy()
        sf.scr=Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        #sf.scr.resizable(False, False)
        sf.pizf1=Frame(sf.scr,height=150,width=1366)
        sf.c=Canvas(sf.pizf1,height=150,width=1366)
        sf.c.pack()
        sf.logo=PhotoImage(file="pzzahut.png")
        sf.c.create_image(683,75,image=sf.logo)
        sf.out=Button(sf.pizf1,text="Log Out",command=lambda:sf.Login(),bg="#0b1335",cursor="hand2",fg="white",font=("default",16))
        sf.out.place(x=1200,y=100)

        sf.pizf1.pack(fill=BOTH,expand=1)

        sf.pizf2=Frame(sf.scr,height=618,width=1366)
        sf.c=Canvas(sf.pizf2,height=618,width=1366)
        sf.c.pack()
        sf.logo1=PhotoImage(file="pizzamain.png")
        sf.c.create_image(683,309,image=sf.logo1)
        sf.deli=PhotoImage(file="delivery.png")
        sf.c.create_image(540,260,image=sf.deli)

        sf.de=Button(sf.pizf2,text="Delivery",cursor="hand2",fg="white",command=lambda:sf.menulist(),bg="#0b1335",font=("default",20),bd=5)
        sf.de.place(x=480,y=400)

        sf.c.create_rectangle(405,125,678,465,outline="black",width=2)
        sf.pizf2.pack(fill=BOTH,expand=1)
        sf.scr.mainloop()

    def menulist(sf):

        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.menuf1 = Frame(sf.scr, height=150, width=1366)
        sf.c = Canvas(sf.menuf1, height=150, width=1366)
        sf.c.pack()
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.c.create_image(683, 75, image=sf.logo)
        sf.home = Button(sf.menuf1, text="Log Out", command=lambda: sf.Login(), bg="#0b1335", cursor="hand2",
                         fg="white", bd=5, font=("default", 16, 'bold'))
        sf.home.place(x=1000, y=90)
        sf.back = Button(sf.menuf1, text="back", command=lambda: sf.pizmain(), bg="#0b1335", cursor="hand2",
                         fg="white", bd=5, font=("default", 16, 'bold'))
        sf.back.place(x=1200, y=90)

        sf.menuf1.pack(fill=BOTH, expand=1)

        sf.menuf2 = Frame(sf.scr, height=618, width=1366)
        sf.c = Canvas(sf.menuf2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.c.create_rectangle(50, 140, 1100, 420, fill="#d3ede6", outline="white", width=6)
        sf.veg = PhotoImage(file="veg.png")
        sf.c.create_image(230, 250, image=sf.veg)
        sf.vegbut = Button(sf.menuf2, text="Veg Pizza", cursor="hand2", fg="white", command=lambda: sf.vegpizza(),
                           bg="#0b1335", bd=5, font=("default", 18, 'bold'))
        sf.vegbut.place(x=170, y=350)
        sf.nonveg = PhotoImage(file="Non.png")
        sf.c.create_image(530, 250, image=sf.nonveg)
        sf.nonvegbut = Button(sf.menuf2, text="Non-Veg Pizza", cursor="hand2", fg="white",
                              command=lambda: sf.nonvegpiz(), bg="#0b1335", bd=5, font=("default", 18, 'bold'))
        sf.nonvegbut.place(x=440, y=350)


        sf.side = PhotoImage(file="extra.png")
        sf.c.create_image(850, 250, image=sf.side)
        sf.sidebut = Button(sf.menuf2, text="Sides and Beverages", cursor="hand2", fg="white",
                            command=lambda: sf.sidebev(), bg="#0b1335", bd=5, font=("default", 18, 'bold'))
        sf.sidebut.place(x=710, y=350)
        sf.menuf2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()
    tot=0
#---------veg pizza---------
    def vegpizza(sf):

            sf.scr.destroy()
            sf.scr = Tk()
            sf.scr.title("pizza hut")
            sf.scr.geometry("1366x768")
            # sf.scr.resizable(False, False)
            sf.vegf1 = Frame(sf.scr, height=150, width=1366)
            sf.c = Canvas(sf.vegf1, height=150, width=1366)
            sf.c.pack()
            sf.logo = PhotoImage(file="pzzahut.png")
            sf.c.create_image(683, 75, image=sf.logo)
            sf.home = Button(sf.vegf1, text="Log Out", command=lambda: sf.Login(), bg="#0b1335", cursor="hand2",
                             fg="white", bd=5, font=("default", 16, 'bold'))
            sf.home.place(x=1000, y=90)

            sf.vegf1.pack(fill=BOTH, expand=1)

            sf.vegf2 = Frame(sf.scr, height=618, width=1366)

            sf.c = Canvas(sf.vegf2, height=618, width=1366)
            sf.c.pack()
            sf.logo1 = PhotoImage(file="pizzamain.png")
            sf.c.create_image(683, 309, image=sf.logo1)
            sf.log = Label(sf.vegf2, text="VEG PIZZA", bg="#9db1f2", font=("Cooper Black", 22))
            sf.log.place(x=600, y=4)
            sf.c.create_rectangle(400, 40, 966, 540, fill="#d3ede6", outline="white", width=6)
            sf.q1 = StringVar()
            sf.q2 = StringVar()
            sf.q3 = StringVar()
            sf.q4 = StringVar()
            sf.q1.set("0")
            sf.q2.set("0")
            sf.q3.set("0")
            sf.q4.set("0")
            # pizza 1
            sf.c.create_rectangle(405, 50, 960, 170, width=2)
            sf.delu = PhotoImage(file="deluxe.png")
            sf.c.create_image(470, 110, image=sf.delu)
            sf.c.create_text(650, 80, text="Deluxe Veggie", fill="#000000", font=("Cooper Black", 20))
            sf.c.create_text(860, 80, text="₹450/₹650/₹250", fill="#ff3838", font=("default", 17, 'bold'))
            # ch1=sf.check(sf.vegf2,100)
            sf.v1 = IntVar()
            sf.C11 = Radiobutton(sf.vegf2, text="Medium", value=10, variable=sf.v1)
            sf.C11.place(x=550, y=100)
            sf.C12 = Radiobutton(sf.vegf2, text="Large", value=20, variable=sf.v1)
            sf.C12.place(x=650, y=100)
            sf.C13 = Radiobutton(sf.vegf2, text="Regular", value=30, variable=sf.v1)
            sf.C13.place(x=750, y=100)
            sf.C11.select()
            sf.C11.deselect()
            sf.C11.invoke()
            sf.c.create_text(590, 150, text="Quantity : ", fill="#000000", font=("default", 12))
            sf.qty1 = Entry(sf.vegf2, textvariable=sf.q1, bg="#aae2d7", font=("default", 12), width=4, )
            sf.qty1.place(x=650, y=140)
            sf.add1 = Button(sf.vegf2, text="ADD", command=lambda: addch1(), bg="#0b1335", cursor="hand2", fg="white",
                             bd=4, font=("default", 12, 'bold'))
            sf.add1.place(x=850, y=120)

            sf.index=0
            def addch1():
                messagebox.showinfo("Cart", "Item Successfully added")
                sf.index=sf.index+1
                file2=open('data2.txt','a+')

                file2.write("deluxe veggie")
                file2.write("|")
                file2.write(sf.qty1.get())
                file2.write('|')
                if sf.v1.get()==10:
                    file2.write("medium")
                    file2.write("|")
                    ans = int(sf.qty1.get()) * 450
                    sf.tot=sf.tot+ans
                    file2.write(str(ans))




                elif sf.v1.get()==20:
                    file2.write("Large")
                    file2.write("|")
                    ans = int(sf.qty1.get()) * 650
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))


                else:
                    file2.write("Regular")
                    file2.write("|")
                    ans = int(sf.qty1.get()) * 250
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                file2.write('|')
                file2.write('$')
                file2.write('\n')

            # pizza 2
            sf.c.create_rectangle(405, 170, 960, 290, width=2)
            sf.vag = PhotoImage(file="extravaganza.png")
            sf.c.create_image(470, 230, image=sf.vag)
            sf.c.create_text(650, 200, text="Veg Vaganza", fill="#000000", font=("Cooper Black", 20))
            sf.c.create_text(860, 200, text="₹400/₹600/₹250", fill="#ff3838", font=("default", 17, 'bold'))
            ##        ch2=sf.check(sf.vegf2,220)
            sf.v2 = IntVar()
            sf.C21 = Radiobutton(sf.vegf2, text="Medium", value=10, variable=sf.v2)
            sf.C21.place(x=550, y=220)
            sf.C22 = Radiobutton(sf.vegf2, text="Large", value=20, variable=sf.v2)
            sf.C22.place(x=650, y=220)
            sf.C23 = Radiobutton(sf.vegf2, text="Regular", value=30, variable=sf.v2)
            sf.C23.place(x=750, y=220)
            sf.C21.select()
            sf.C21.deselect()
            sf.C21.invoke()
            sf.c.create_text(590, 270, text="Quantity : ", fill="#000000", font=("default", 12))
            sf.qty2 = Entry(sf.vegf2, textvariable=sf.q2, bg="#aae2d7", font=("default", 12), width=4, )
            sf.qty2.place(x=650, y=260)
            sf.add2 = Button(sf.vegf2, text="ADD", command=lambda: addch2(), bg="#0b1335", cursor="hand2", fg="white",
                             bd=4, font=("default", 12, 'bold'))
            sf.add2.place(x=850, y=240)


            def addch2():
                messagebox.showinfo("Cart", "Item Successfully added")
                file2 = open('data2.txt', 'a+')
                file2.write('\n')
                file2.write("veg vaganza")
                file2.write('|')
                file2.write(sf.qty2.get())
                file2.write('|')
                if sf.v2.get() == 10:
                    file2.write("medium")
                    file2.write("|")
                    ans = int(sf.qty2.get()) * 400
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))


                elif sf.v2.get() == 20:
                    file2.write("Large")
                    file2.write("|")
                    ans = int(sf.qty2.get()) * 600
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))


                else:
                    file2.write("Regular")
                    file2.write("|")
                    ans = int(sf.qty2.get()) * 250
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                file2.write('|')
                file2.write('$')
                file2.write('\n')

            # pizza 3
            sf.c.create_rectangle(405, 290, 960, 410, width=2)
            sf.pep = PhotoImage(file="5-pepper-veg-pizza.png")
            sf.c.create_image(470, 350, image=sf.pep)
            sf.c.create_text(650, 320, text="5 Pepper", fill="#000000", font=("Cooper Black", 20))
            sf.c.create_text(860, 320, text="₹385/₹550/₹225", fill="#ff3838", font=("default", 17, 'bold'))
            # ch3=sf.check(sf.vegf2,340)
            sf.v3 = IntVar()
            sf.C31 = Radiobutton(sf.vegf2, text="Medium", value=10, variable=sf.v3)
            sf.C31.place(x=550, y=340)
            sf.C32 = Radiobutton(sf.vegf2, text="Large", value=20, variable=sf.v3)
            sf.C32.place(x=650, y=340)
            sf.C33 = Radiobutton(sf.vegf2, text="Regular", value=30, variable=sf.v3)
            sf.C33.place(x=750, y=340)
            sf.C31.select()
            sf.C31.deselect()
            sf.C31.invoke()

            sf.c.create_text(590, 390, text="Quantity : ", fill="#000000", font=("default", 12))
            sf.qty3 = Entry(sf.vegf2, textvariable=sf.q3, bg="#aae2d7", font=("default", 12), width=4, )
            sf.qty3.place(x=650, y=380)

            sf.add3 = Button(sf.vegf2, text="ADD", command=lambda: addch3(), bg="#0b1335", cursor="hand2", fg="white",
                             bd=4, font=("default", 12, 'bold'))
            sf.add3.place(x=850, y=360)


            def addch3():
                messagebox.showinfo("Cart", "Item Successfully added")
                file2 = open('data2.txt', 'a+')
                file2.write('\n')
                file2.write("pepper veg pizza")
                file2.write('|')
                file2.write(sf.qty3.get())
                file2.write('|')
                if sf.v3.get() == 10:
                    file2.write("medium")
                    file2.write("|")
                    ans = int(sf.qty3.get()) * 385
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                elif sf.v3.get() == 20:
                    file2.write("Large")
                    file2.write("|")
                    ans = int(sf.qty3.get()) * 550
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                else:
                    file2.write("Regular")
                    file2.write("|")
                    ans = int(sf.qty3.get()) * 225
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))
                file2.write('|')
                file2.write('$')
                file2.write('\n')


            # pizza 4
            sf.c.create_rectangle(405, 410, 960, 530, width=2)
            sf.mag = PhotoImage(file="Margherit.png")
            sf.c.create_image(470, 470, image=sf.mag)
            sf.c.create_text(650, 440, text="Margherita", fill="#000000", font=("Cooper Black", 20))
            sf.c.create_text(860, 440, text="₹195/₹385/₹99", fill="#ff3838", font=("default", 17, 'bold'))
            # ch4=sf.check(sf.vegf2,460)
            sf.v4 = IntVar()
            sf.C41 = Radiobutton(sf.vegf2, text="Medium", value=10, variable=sf.v4)
            sf.C41.place(x=550, y=460)
            sf.C42 = Radiobutton(sf.vegf2, text="Large", value=20, variable=sf.v4)
            sf.C42.place(x=650, y=460)
            sf.C43 = Radiobutton(sf.vegf2, text="Regular", value=30, variable=sf.v4)
            sf.C43.place(x=750, y=460)
            sf.C41.select()
            sf.C41.deselect()
            sf.C41.invoke()

            sf.c.create_text(590, 500, text="Quantity : ", fill="#000000", font=("default", 12))
            sf.qty4 = Entry(sf.vegf2, textvariable=sf.q4, bg="#aae2d7", font=("default", 12), width=4, )
            sf.qty4.place(x=650, y=500)

            sf.add4 = Button(sf.vegf2, text="ADD", command=lambda: addch4(), bg="#0b1335", cursor="hand2", fg="white",
                             bd=4, font=("default", 12, 'bold'))
            sf.add4.place(x=850, y=480)


            def addch4():
                messagebox.showinfo("Cart", "Item Successfully added")
                file2 = open('data2.txt', 'a+')
                file2.write('\n')
                file2.write("margherita")
                file2.write('|')
                file2.write(sf.qty4.get())
                file2.write('|')

                if sf.v4.get() == 10:
                    file2.write("medium")
                    file2.write("|")
                    ans = int(sf.qty4.get()) * 385
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                elif sf.v4.get() == 20:
                    file2.write("Large")
                    file2.write("|")
                    ans = int(sf.qty4.get()) * 550
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))

                else:
                    file2.write("Regular")
                    file2.write("|")
                    ans = int(sf.qty4.get()) * 225
                    sf.tot = sf.tot + ans
                    file2.write(str(ans))
                file2.write('|')
                file2.write('$')
                file2.write('\n')


            sf.con = Button(sf.vegf2, text="Confirm Order", command= lambda :sf.Orderd(), bg="#0b1335", cursor="hand2", fg="white", bd=5, font=("default", 18, 'bold'))

            sf.con.place(x=1050, y=250)
            sf.more = Button(sf.vegf2, text="Add More..", command=lambda: sf.menulist(), bg="#0b1335",
                             cursor="hand2", fg="white", bd=5, font=("default", 18, 'bold'))
            sf.more.place(x=1050, y=350)
            sf.vegf2.pack(fill=BOTH, expand=1)
            sf.scr.mainloop()

#--------nonveg---------------------
    def nonvegpiz(sf):

        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.nonvegf1 = Frame(sf.scr, height=150, width=1366)
        sf.c = Canvas(sf.nonvegf1, height=150, width=1366)
        sf.c.pack()
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.c.create_image(683, 75, image=sf.logo)
        sf.home = Button(sf.nonvegf1, text="Log Out", command=lambda: sf.Login(), bg="#0b1335", cursor="hand2",
                         fg="white", bd=5, font=("default", 16, 'bold'))
        sf.home.place(x=1000, y=90)

        sf.nonvegf1.pack(fill=BOTH, expand=1)

        sf.nonvegf2 = Frame(sf.scr, height=618, width=1366)

        sf.c = Canvas(sf.nonvegf2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.log = Label(sf.nonvegf2, text="NON-VEG PIZZA", bg="#9db1f2", font=("Cooper Black", 22))
        sf.log.place(x=580, y=4)
        sf.c.create_rectangle(400, 40, 966, 540, fill="#d3ede6", outline="white", width=6)
        sf.q5 = StringVar()
        sf.q6 = StringVar()
        sf.q7 = StringVar()
        sf.q8 = StringVar()
        sf.q5.set("0")
        sf.q6.set("0")
        sf.q7.set("0")
        sf.q8.set("0")
        # pizza 1
        sf.c.create_rectangle(405, 50, 960, 170, width=2)
        sf.delu = PhotoImage(file="Non-Veg_Supreme.png")
        sf.c.create_image(470, 110, image=sf.delu)
        sf.c.create_text(650, 80, text="Non-Veg Supreme", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(860, 80, text="₹450/₹650/₹250", fill="#ff3838", font=("default", 17, 'bold'))
        # ch5=sf.check(sf.nonvegf2,100)
        sf.v5 = IntVar()
        sf.C51 = Radiobutton(sf.nonvegf2, text="Medium", value=10, variable=sf.v5)
        sf.C51.place(x=550, y=100)
        sf.C52 = Radiobutton(sf.nonvegf2, text="Large", value=20, variable=sf.v5)
        sf.C52.place(x=650, y=100)
        sf.C53 = Radiobutton(sf.nonvegf2, text="Regular", value=30, variable=sf.v5)
        sf.C53.place(x=750, y=100)
        sf.C51.select()
        sf.C51.deselect()
        sf.C51.invoke()
        sf.c.create_text(590, 150, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty5 = Entry(sf.nonvegf2, textvariable=sf.q5, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty5.place(x=650, y=140)

        sf.add5 = Button(sf.nonvegf2, text="ADD", command=lambda: addch5(), bg="#0b1335", cursor="hand2", fg="white",
                         bd=4, font=("default", 12, 'bold'))
        sf.add5.place(x=850, y=120)


        def addch5():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("non veg supreme")
            file2.write('|')

            file2.write(sf.qty5.get())
            file2.write('|')
            if sf.v5.get() == 10:
                file2.write("medium")
                file2.write("|")
                ans = int(sf.qty5.get()) * 450
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            elif sf.v5.get() == 20:
                file2.write("Large")
                file2.write("|")
                ans = int(sf.qty5.get()) * 650
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            else:
                file2.write("Regular")
                file2.write("|")
                ans = int(sf.qty5.get()) * 250
                sf.tot = sf.tot + ans
                file2.write(str(ans))
            file2.write('|')
            file2.write('$')
            file2.write('\n')


        # pizza 2
        sf.c.create_rectangle(405, 170, 960, 290, width=2)
        sf.vag = PhotoImage(file="nonChicken_Tikka.png")
        sf.c.create_image(470, 230, image=sf.vag)
        sf.c.create_text(650, 200, text="Chicken Tikka", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(860, 200, text="₹400/₹600/₹250", fill="#ff3838", font=("default", 17, 'bold'))
        # ch6=sf.check(sf.nonvegf2,220)
        sf.v6 = IntVar()
        sf.C61 = Radiobutton(sf.nonvegf2, text="Medium", value=10, variable=sf.v6)
        sf.C61.place(x=550, y=220)
        sf.C62 = Radiobutton(sf.nonvegf2, text="Large", value=20, variable=sf.v6)
        sf.C62.place(x=650, y=220)
        sf.C63 = Radiobutton(sf.nonvegf2, text="Regular", value=30, variable=sf.v6)
        sf.C63.place(x=750, y=220)
        sf.C61.select()
        sf.C61.deselect()
        sf.C61.invoke()
        sf.c.create_text(590, 270, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty6 = Entry(sf.nonvegf2, textvariable=sf.q6, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty6.place(x=650, y=260)

        sf.add6 = Button(sf.nonvegf2, text="ADD", command=lambda: addch6(), bg="#0b1335", cursor="hand2", fg="white",
                         bd=4, font=("default", 12, 'bold'))
        sf.add6.place(x=850, y=240)


        def addch6():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("chicken tikka")
            file2.write('|')
            file2.write(sf.qty6.get())
            file2.write('|')
            if sf.v6.get() == 10:
                file2.write("medium")
                file2.write("|")
                ans = int(sf.qty6.get()) * 400
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            elif sf.v6.get() == 20:
                file2.write("Large")
                file2.write("|")
                ans = int(sf.qty6.get()) * 600
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            else:
                file2.write("Regular")
                file2.write("|")
                ans = int(sf.qty6.get()) * 250
                sf.tot = sf.tot + ans
                file2.write(ans)
            file2.write('|')
            file2.write('$')
            file2.write('\n')


        # pizza 3
        sf.c.create_rectangle(405, 290, 960, 410, width=2)
        sf.pep = PhotoImage(file="non-Chicken_Sausage.png")
        sf.c.create_image(470, 350, image=sf.pep)
        sf.c.create_text(650, 320, text="Chicken Sausage", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(860, 320, text="₹385/₹550/₹225", fill="#ff3838", font=("default", 17, 'bold'))
        # ch7=sf.check(sf.nonvegf2,340)
        sf.v7 = IntVar()
        sf.C71 = Radiobutton(sf.nonvegf2, text="Medium", value=10, variable=sf.v7)
        sf.C71.place(x=550, y=340)
        sf.C72 = Radiobutton(sf.nonvegf2, text="Large", value=20, variable=sf.v7)
        sf.C72.place(x=650, y=340)
        sf.C73 = Radiobutton(sf.nonvegf2, text="Regular", value=30, variable=sf.v7)
        sf.C73.place(x=750, y=340)
        sf.C71.select()
        sf.C71.deselect()
        sf.C71.invoke()
        sf.c.create_text(590, 390, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty7 = Entry(sf.nonvegf2, textvariable=sf.q7, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty7.place(x=650, y=380)

        sf.add7 = Button(sf.nonvegf2, text="ADD", command=lambda: addch7(), bg="#0b1335", cursor="hand2", fg="white",
                         bd=4, font=("default", 12, 'bold'))
        sf.add7.place(x=850, y=360)


        def addch7():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("chicken sausage")
            file2.write('|')
            file2.write(sf.qty7.get())
            file2.write('|')
            if sf.v7.get() == 10:
                file2.write("medium")
                file2.write("|")
                ans=int(sf.qty7.get())*385
                sf.tot = sf.tot + ans
                file2.write(str(ans))


            elif sf.v7.get() == 20:
                file2.write("Large")
                file2.write("|")
                ans = int(sf.qty7.get()) * 550
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            else:
                file2.write("Regular")
                file2.write("|")
                ans = int(sf.qty7.get()) * 225
                sf.tot = sf.tot + ans
                file2.write(str(ans))
            file2.write('|')
            file2.write('$')

            file2.write('\n')


        # pizza 4
        sf.c.create_rectangle(405, 410, 960, 530, width=2)
        sf.mag = PhotoImage(file="no-LoadedL.png")
        sf.c.create_image(470, 470, image=sf.mag)
        sf.c.create_text(650, 440, text="Chicken Peri", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(860, 440, text="₹195/₹385/₹99", fill="#ff3838", font=("default", 17, 'bold'))
        # ch8=sf.check(sf.nonvegf2,460)
        sf.v8 = IntVar()
        sf.C81 = Radiobutton(sf.nonvegf2, text="Medium", value=10, variable=sf.v8)
        sf.C81.place(x=550, y=460)
        sf.C82 = Radiobutton(sf.nonvegf2, text="Large", value=20, variable=sf.v8)
        sf.C82.place(x=650, y=460)
        sf.C83 = Radiobutton(sf.nonvegf2, text="Regular", value=30, variable=sf.v8)
        sf.C83.place(x=750, y=460)
        sf.C81.select()
        sf.C81.deselect()
        sf.C81.invoke()
        sf.c.create_text(590, 500, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty8 = Entry(sf.nonvegf2, textvariable=sf.q8, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty8.place(x=650, y=500)
        sf.add8 = Button(sf.nonvegf2, text="ADD", command=lambda: addch8(), bg="#0b1335", cursor="hand2", fg="white",
                         bd=4, font=("default", 12, 'bold'))
        sf.add8.place(x=850, y=480)

        def addch8():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("chicken peri")
            file2.write('|')
            file2.write(sf.qty8.get())
            file2.write('|')
            if sf.v8.get() == 10:
                file2.write("medium")
                file2.write("|")
                ans = int(sf.qty8.get()) * 195
                sf.tot = sf.tot + ans
                file2.write(str(ans))




            elif sf.v8.get() == 20:
                file2.write("Large")
                file2.write("|")
                ans = int(sf.qty8.get()) * 385
                sf.tot = sf.tot + ans
                file2.write(str(ans))

            else:
                file2.write("Regular")
                file2.write("|")
                ans = int(sf.qty8.get()) * 99
                sf.tot = sf.tot + ans
                file2.write(str(ans))
            file2.write('|')
            file2.write('$')
            file2.write('\n')


        sf.con = Button(sf.nonvegf2, text="Confirm Order", command=lambda :sf.Orderd(), bg="#0b1335",
                        cursor="hand2", fg="white", bd=5, font=("default", 18, 'bold'))
        sf.con.place(x=1050, y=250)
        sf.more = Button(sf.nonvegf2, text="Add More..", command=lambda: sf.menulist(), bg="#0b1335",
                         cursor="hand2", fg="white", bd=5, font=("default", 18, 'bold'))
        sf.more.place(x=1050, y=350)

        sf.nonvegf2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()
#--------Special Chicken-----------------
    def sidebev(sf):

        sf.scr.destroy()
        sf.scr = Tk()
        sf.scr.title("pizza hut")
        sf.scr.geometry("1366x768")
        # sf.scr.resizable(False, False)
        sf.sidef1 = Frame(sf.scr, height=150, width=1366)
        sf.c = Canvas(sf.sidef1, height=150, width=1366)
        sf.c.pack()
        sf.logo = PhotoImage(file="pzzahut.png")
        sf.c.create_image(683, 75, image=sf.logo)
        sf.home = Button(sf.sidef1, text="Log Out", command=lambda: sf.Login(), bg="#0b1335", cursor="hand2",
                         fg="white", bd=5, font=("default", 16, 'bold'))
        sf.home.place(x=1000, y=90)

        sf.sidef1.pack(fill=BOTH, expand=1)

        sf.sidef2 = Frame(sf.scr, height=618, width=1366)

        sf.c = Canvas(sf.sidef2, height=618, width=1366)
        sf.c.pack()
        sf.logo1 = PhotoImage(file="pizzamain.png")
        sf.c.create_image(683, 309, image=sf.logo1)
        sf.log = Label(sf.sidef2, text="SIDES & BEVERAGES", bg="#9db1f2", font=("Cooper Black", 22))
        sf.log.place(x=520, y=4)
        sf.c.create_rectangle(400, 40, 966, 420, fill="#d3ede6", outline="white", width=6)
        sf.q12 = StringVar()
        sf.q13 = StringVar()
        sf.q14 = StringVar()
        sf.q12.set("0")
        sf.q13.set("0")
        sf.q14.set("0")
        # pizza 1
        sf.c.create_rectangle(405, 50, 960, 170, width=2)
        sf.delu = PhotoImage(file="coke.png")
        sf.c.create_image(470, 110, image=sf.delu)
        sf.c.create_text(650, 80, text="Coke Mobile", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(875, 80, text="₹45", fill="#ff3838", font=("default", 17, 'bold'))
        sf.c.create_text(590, 120, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty12 = Entry(sf.sidef2, textvariable=sf.q12, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty12.place(x=650, y=110)
        sf.add12 = Button(sf.sidef2, text="ADD",
                          command=lambda: addbev(),
                          bg="#0b1335", cursor="hand2", fg="white", bd=4, font=("default", 12, 'bold'))
        sf.add12.place(x=850, y=120)

        def addbev():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("Coke")
            file2.write('|')
            file2.write(sf.qty12.get())
            file2.write('|')
            file2.write('null')
            file2.write('|')
            ans = int(sf.qty12.get()) * 45
            file2.write(str(ans))
            file2.write('|')
            file2.write('$')
            file2.write('\n')




        sf.c.create_rectangle(405, 170, 960, 290, width=2)
        sf.vag = PhotoImage(file="burger.png")
        sf.c.create_image(470, 230, image=sf.vag)
        sf.c.create_text(650, 200, text="Burger Pizza", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(875, 200, text="₹99", fill="#ff3838", font=("default", 17, 'bold'))
        sf.c.create_text(590, 240, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty13 = Entry(sf.sidef2, textvariable=sf.q13, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty13.place(x=650, y=230)
        sf.add13 = Button(sf.sidef2, text="ADD",
                          command=lambda: addbev2(),
                          bg="#0b1335", cursor="hand2", fg="white", bd=4, font=("default", 12, 'bold'))
        sf.add13.place(x=850, y=240)

        def addbev2():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+')
            file2.write('\n')
            file2.write("Burger pizza")
            file2.write('|')
            file2.write(sf.qty13.get())
            file2.write('|')
            file2.write('null')
            file2.write('|')
            ans = int(sf.qty13.get()) * 99
            file2.write(str(ans))
            file2.write('|')
            file2.write('$')
            file2.write('\n')


        # pizza 3
        sf.c.create_rectangle(405, 290, 960, 410, width=2)
        sf.pep = PhotoImage(file="white.png")
        sf.c.create_image(470, 350, image=sf.pep)
        sf.c.create_text(650, 320, text="White Pasta", fill="#000000", font=("Cooper Black", 20))
        sf.c.create_text(875, 320, text="₹135", fill="#ff3838", font=("default", 17, 'bold'))
        sf.c.create_text(590, 360, text="Quantity : ", fill="#000000", font=("default", 12))
        sf.qty14 = Entry(sf.sidef2, textvariable=sf.q14, bg="#aae2d7", font=("default", 12), width=4, )
        sf.qty14.place(x=650, y=350)
        sf.add14 = Button(sf.sidef2, text="ADD",
                          command=lambda:addbev3() ,
                          bg="#0b1335", cursor="hand2", fg="white", bd=4, font=("default", 12, 'bold'))
        sf.add14.place(x=850, y=360)


        def addbev3():
            messagebox.showinfo("Cart", "Item Successfully added")
            file2 = open('data2.txt', 'a+',newline='')
            file2.write('\n')
            file2.write("White pasta")
            file2.write('|')
            file2.write(str(sf.qty14.get()))
            file2.write('|')
            file2.write('null')
            file2.write('|')
            ans = int(sf.qty14.get()) * 135
            file2.write(str(ans))
            file2.write('|')
            file2.write('$')
            file2.write('\n')


        sf.con = Button(sf.sidef2, text="Confirm Order", command=lambda :sf.Orderd(), bg="#0b1335", cursor="hand2",
                        fg="white", bd=5, font=("default", 18, 'bold'))
        sf.con.place(x=600, y=430)
        sf.more = Button(sf.sidef2, text="Add More..", command=lambda: sf.menulist(), bg="#0b1335", cursor="hand2",
                         fg="white", bd=5, font=("default", 16, 'bold'))
        sf.more.place(x=630, y=500)
        sf.sidef2.pack(fill=BOTH, expand=1)
        sf.scr.mainloop()

    def Orderd(sf):
        print(sf.tot)
        orderd()

    #-------login data----------
    def logindata(sf):
        infile = open('data.txt', 'r')
        for line in infile:
            print(line)
            fields = line.split('|')


        if sf.user.get()=="" or sf.pasd.get()=="":
            messagebox.showinfo("Login","Empty Entry is not allowed")

        if fields[1] == sf.user.get() and check_password_hash(fields[2], sf.pasd.get()):
            print(fields[0])
            messagebox.showinfo("Login", "You have Successfully Log In\nWelcome to Pizza Hut")
            sf.pizmain()

        if fields[1]!=sf.user.get() or  check_password_hash(fields[2], sf.pasd.get()):
            messagebox.showinfo("Login", "You are Not Registered Yet")
        infile.close()







x=Pizza()
x.main()

