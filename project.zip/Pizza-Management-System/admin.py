from tkinter import *
from tkinter import ttk
from searchuser import *
data = []
name=""
def view():
    outfile = open('data3.txt', 'r')

    for line in outfile:
        items = line.split('|')
        data.append(items)
    data.sort()
    outfile.close()

    return data


def orderd2():
    global name
    co2 = "#4456F0"
    window = Tk()
    window.title("customer details")
    window.geometry("480x450")
    window.configure(background="#ffffff")
    window.resizable(width=FALSE, height=FALSE)
    frame_table = Frame(window, width=4500, height=1000, bg="#ffffff")
    frame_table.grid(row=2, column=0, columnspan=2, padx=0, pady=1, sticky=NW)
    rg = Button(window, text="search", cursor="hand2",fg="white",command=lambda :val(),bg="#0b1335", font=("cooper black", 10), bd=5)
    rg.place(x=200, y=250)
    passd = Entry(window, bg="white", width=15, font=("cooper black", 10), bd=5)
    passd.place(x=280, y=250)



    def val():
        file = open("search.txt", 'w')
        file.write(passd.get())
        file.close()
        order()

    def show():
        global tree

        list_header = ['username', 'firstname', 'lastname','email']
        demo_list = view()
        tree = ttk.Treeview(frame_table, selectmode="extended", columns=list_header, show="headings")

        tree.grid(column=0, row=0, sticky='nsew')

        tree.heading(0, text='username', anchor=NW)
        tree.heading(1, text='lastname', anchor=NW)
        tree.heading(2, text='firstname', anchor=NW)
        tree.heading(3, text='email', anchor=NW)



        tree.column(0, width=100, anchor='nw')
        tree.column(1, width=100, anchor='nw')
        tree.column(2, width=100, anchor='nw')
        tree.column(3, width=180, anchor='nw')




        for item in demo_list:
            tree.insert('', 'end', values=item)


    show()



    window.mainloop()



