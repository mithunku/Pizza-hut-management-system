from zipfile import ZipFile
file1='data.txt'
f=ZipFile('data4.zip','w')
f.write('data.txt')
f.write('data2.txt')
f.write('data3.txt')
f.close()

