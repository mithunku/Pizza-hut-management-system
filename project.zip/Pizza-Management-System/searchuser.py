from tkinter import *
from tkinter import ttk
from admin import *
data = []


def view():
    outfile = open('data3.txt', 'r')
    file=open('search.txt','r')
    for i in file:
        n=i;

    for line in outfile:
        items = line.split('|')
        if(n==items[0]):
            data.append(items)
    data.sort()
    outfile.close()

    return data


def order():
    co2 = "#4456F0"
    window = Tk()
    window.title("search result")
    window.geometry("480x450")
    window.configure(background="#ffffff")
    window.resizable(width=FALSE, height=FALSE)
    frame_table = Frame(window, width=4500, height=1000, bg="#ffffff")
    frame_table.grid(row=2, column=0, columnspan=2, padx=0, pady=1, sticky=NW)


    def show():
        global tree

        list_header = ['username', 'firstname', 'lastname','email']
        demo_list = view()
        tree = ttk.Treeview(frame_table, selectmode="extended", columns=list_header, show="headings")

        tree.grid(column=0, row=0, sticky='nsew')

        tree.heading(0, text='username', anchor=NW)
        tree.heading(1, text='lastname', anchor=NW)
        tree.heading(2, text='firstname', anchor=NW)
        tree.heading(3, text='email', anchor=NW)



        tree.column(0, width=100, anchor='nw')
        tree.column(1, width=100, anchor='nw')
        tree.column(2, width=100, anchor='nw')
        tree.column(3, width=180, anchor='nw')




        for item in demo_list:
            tree.insert('', 'end', values=item)


    show()



    window.mainloop()
