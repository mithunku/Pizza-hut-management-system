from tkinter import *
from tkinter import ttk

data = []
def view():

    outfile=open('data2.txt','r')

    for line in outfile:
        items=line.split('|')
        data.append(items)

    outfile.close()
    return data
def orderd():
    co2="#4456F0"
    window=Tk()
    window.title("order details")
    window.geometry("485x450")
    window.configure(background="#ffffff")
    window.resizable(width=FALSE,height=FALSE)
    frame_table=Frame(window,width=4500,height=1000,bg="#ffffff")
    frame_table.grid(row=2,column=0,columnspan=2,padx=0,pady=1,sticky=NW)




    def show():
        global tree

        list_header=['items','quantity','Size','Price']
        demo_list=view()
        tree=ttk.Treeview(frame_table,selectmode="extended",columns=list_header,show="headings")

        tree.grid(column=0,row=0,sticky='nsew')



        tree.heading(0,text='Items',anchor=NW)
        tree.heading(1, text='Quantity', anchor=NW)
        tree.heading(2, text='Size', anchor=NW)
        tree.heading(3, text='Price', anchor=NW)

        tree.column(0,width=100,anchor='nw')
        tree.column(1, width=100, anchor='nw')
        tree.column(2, width=100, anchor='nw')
        tree.column(3, width=180, anchor='nw')

        for item in demo_list:
            tree.insert('','end',values=item)

    show()
    def remove():
        try:
            tree_data=tree.focus()
            tree_dict=tree.item(tree_data)
            tree_list=tree_dict['values']
        except:
            pass

    window.mainloop()
